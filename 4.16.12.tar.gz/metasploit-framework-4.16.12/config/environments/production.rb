if defined? Metasploit::Framework::Application
  Metasploit::Framework::Application.configure do
    config.log_level = :info
  end
end
