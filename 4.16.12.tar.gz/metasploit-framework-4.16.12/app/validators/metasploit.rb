require 'metasploit/framework/file_path_validator'
require 'metasploit/framework/executable_path_validator'